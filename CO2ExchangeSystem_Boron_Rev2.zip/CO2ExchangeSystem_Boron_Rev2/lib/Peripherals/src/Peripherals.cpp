#include "Peripherals.h"

namespace deltaPCo2{

    Peripherals::Peripherals(USARTSerial& aUsartSerial, USBSerial& aUsbSerial)
    : serial(aUsartSerial), anActiveSerial(aUsbSerial), extSerial(Wire, 0){
        pinMode(PUMP, OUTPUT);
        czr = new COZIR(aUsartSerial);
        valve1 = new Solenoid(AIN1, AIN2, PWMA, STBY);
        valve2 = new Solenoid(BIN1, BIN2, PWMB, STBY);
        co2List = new std::vector<int>;
        czr->SetOperatingMode(CZR_COMMAND);
        czr->CalibrateFreshAir();
        Wire.begin();
        extSerial.begin(9600);

    }


    Peripherals::~Peripherals(){
        if(czr){delete czr;}
        if(co2List){delete[] co2List;}
        if(sdout){sdout.close();}
        if(valve1){delete valve1;}
        if(valve2){delete valve2;}
    }

/////////////////////////////////////////////////
// 
/////////////////////////////////////////////////

	void Peripherals::getCo2(T& aTimeTable){
        int aCo2 = 0;


        //---Starting to pump from Air side to Ocean side--------------------------------------------------------------
        valve1->CA();
        valve2->CA();
        pump(ON);

        co2List->clear();
        int stateTime = millis();
        while(!((millis() - stateTime) >=  (aTimeTable.samplingDuration/2) * 60000))
        { 
            aCo2 = czr->CO2();
            co2List->push_back(aCo2);
            delay((int)(60000 / aTimeTable.samplingRate ));
            Serial.print(aCo2); Serial.print(" ");
        }
        pump(OFF);
        //---Adding a Seperator Value-------------------------------------------------------------------------------

        co2List->push_back(aCo2=-1);
        Serial.print("| ");
        delay(200);

        //---Starting to pump from Ocean side to Air side--------------------------------------------------------------
        valve1->CB();
        valve2->CB();
        pump(ON);

        stateTime = millis();
        while(!((millis() - stateTime) >=  (aTimeTable.samplingDuration/2) * 60000))
        { 
            aCo2 = czr->CO2();
            co2List->push_back(aCo2);
            delay((int)(60000 / aTimeTable.samplingRate ));
            Serial.print(aCo2); Serial.print(" ");
        }
        pump(OFF);

        
        //std::sort(co2List->begin(), co2List->end());
        //int indexofMedian = co2List->size()/2;
        //aData.co2=co2List[indexofMedian];

    }

    void Peripherals::getHumidityAndTemp(){
        aData.humidity = czr->Celsius();
        aData.temperature = czr->Humidity();
    }

    SensorsData Peripherals::getSensorsData(T& aTimeTable){
        Serial.println(" Getting Sensors Data....."); 
        Serial.print(" Sampling Co2 for "); Serial.print(TimeTable.samplingDuration); Serial.println(" minutes "); 
        Serial.print(" With sampling rate of ");Serial.print(TimeTable.samplingRate); Serial.println(" Hertz.");
        getHumidityAndTemp();
        getCo2(aTimeTable);
        getGPS();
        return aData;
    }


    void Peripherals::getGPS(){

        std::string op;
        long double lat=0.0;
        long double lng=0.0;
        size_t GNRMCIndex=0;

        Serial.print("\n");
        int stateTime = millis();
        while(extSerial.available() && !((millis() - stateTime) >=  3000)){
            op += extSerial.read(); 
        }
        //Serial.println(op.c_str());
        if ((GNRMCIndex = op.find("$GNRMC"))!= std::string::npos){
             size_t CommaIndex = op.find(',');
             op.erase (0, CommaIndex+1);
             CommaIndex = op.find(',');
             op.erase (0, CommaIndex+1);
             CommaIndex = op.find(',');
             op.erase (0, CommaIndex+1);
             CommaIndex = op.find(',');
             lat = std::stold(op.substr(0,CommaIndex),nullptr);
             op.erase (0, CommaIndex+1);
             CommaIndex = op.find(',');
             op.erase (0, CommaIndex+1);
             CommaIndex = op.find(',');
             lng = std::stold(op.substr(0,CommaIndex),nullptr);
        }
         aData.latitude = lat*100000;
         aData.longitude = lng*-100000;  
        // if (!myGPS.begin()){
        //     Serial.println(F("\n GPS Freezing, Please check wiring..."));
        // }
        // myGPS.setI2COutput(COM_TYPE_UBX); //Set the I2C port to output UBX only (turn off NMEA noise)
        // myGPS.saveConfiguration(); //Save the current settings to flash and BBR
        //int stateTime = millis();
        // while(!((millis() - stateTime) >=  0.1 * 60000)){ 
        //     aData.latitude = myGPS.getLatitude();
        //     aData.longitude = myGPS.getLongitude();
        // } 

        //while(!((millis() - stateTime) >=  0.1 * 60000)){ 
            //extSerial.readString();
            //Serial.print(extSerial.readString());
        //     aData.latitude = myGPS.getLatitude();
        //     aData.longitude = myGPS.getLongitude();
        //} 
    }


    void Peripherals::pump(byte state){
       digitalWrite(PUMP, state); 
    }



    /////////////////////////////////////////////////
	// 
	///////////////////////////////////////////////// 


    ostream& operator<<(ostream& os, const String& aString){
        os << aString.c_str();
        return os;
    }


    void Peripherals::writeSensorData(){

        if(!this->sd.begin(SD_CS_PIN)) {
            Serial.println(" SD init failed!");
        }
        sdout.open("DataLog.txt", ios_base::app);


        //---------------------------------------------------
        DateTime now = rtc.now();
        sdout << now.now().c_str()    << ", ";
        Serial.print(now.now().c_str()); Serial.print('\n');
        //---------------------------------------------------

        sdout << aData.longitude   << ", ";
        sdout << aData.latitude    << ", ";
        sdout << aData.humidity    << ", ";
        sdout << aData.temperature;  

        //---------------------------------------------------
        for (std::vector<int>::iterator it = co2List->begin() ; it != co2List->end(); ++it){
            sdout << ", " << *it;
        }
        sdout << "\n";

        //---------------------------------------------------

        sdout.close();
    }

    
}