var searchData=
[
  ['spiclockspeedmhz',['spiClockSpeedMHz',['../class_s_c16_i_s740_s_p_i.html#a44b58ef1f07200e5833870f6756f6806',1,'SC16IS740SPI']]]
];
