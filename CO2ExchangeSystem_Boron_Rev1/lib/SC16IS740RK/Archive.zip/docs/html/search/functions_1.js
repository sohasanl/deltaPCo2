var searchData=
[
  ['begin',['begin',['../class_s_c16_i_s740_base.html#a01cf74d26ed768fd404d7200e28c705e',1,'SC16IS740Base']]],
  ['begintransaction',['beginTransaction',['../class_s_c16_i_s740_s_p_i.html#acfdd43458969269c7790321ba5240ebd',1,'SC16IS740SPI']]],
  ['blockonoverrun',['blockOnOverrun',['../class_s_c16_i_s740_base.html#ac435975db928fa5739d2aeb4d747d5c7',1,'SC16IS740Base']]]
];
