var searchData=
[
  ['sc16is740',['SC16IS740',['../class_s_c16_i_s740.html#a994c4e99fdea75946b18c56aab4d42a5',1,'SC16IS740']]],
  ['sc16is740spi',['SC16IS740SPI',['../class_s_c16_i_s740_s_p_i.html#a714ca549b988bbe5fe812301ad7a182e',1,'SC16IS740SPI']]],
  ['setspisettings',['setSpiSettings',['../class_s_c16_i_s740_s_p_i.html#af85c3be21295baf5045569db308f40a3',1,'SC16IS740SPI']]],
  ['settimeout',['setTimeout',['../class_stream.html#abaa50647d6dbb3baf7697a2691a06177',1,'Stream']]]
];
