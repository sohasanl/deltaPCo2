var searchData=
[
  ['sc16is740rk',['SC16IS740RK',['../index.html',1,'']]],
  ['sc16is740',['SC16IS740',['../class_s_c16_i_s740.html',1,'SC16IS740'],['../class_s_c16_i_s740.html#a994c4e99fdea75946b18c56aab4d42a5',1,'SC16IS740::SC16IS740()']]],
  ['sc16is740base',['SC16IS740Base',['../class_s_c16_i_s740_base.html',1,'']]],
  ['sc16is740spi',['SC16IS740SPI',['../class_s_c16_i_s740_s_p_i.html',1,'SC16IS740SPI'],['../class_s_c16_i_s740_s_p_i.html#a714ca549b988bbe5fe812301ad7a182e',1,'SC16IS740SPI::SC16IS740SPI()']]],
  ['setspisettings',['setSpiSettings',['../class_s_c16_i_s740_s_p_i.html#af85c3be21295baf5045569db308f40a3',1,'SC16IS740SPI']]],
  ['settimeout',['setTimeout',['../class_stream.html#abaa50647d6dbb3baf7697a2691a06177',1,'Stream']]],
  ['spark_5fwiring_5fprint_2eh',['spark_wiring_print.h',['../spark__wiring__print_8h.html',1,'']]],
  ['spark_5fwiring_5fstream_2eh',['spark_wiring_stream.h',['../spark__wiring__stream_8h.html',1,'']]],
  ['spiclockspeedmhz',['spiClockSpeedMHz',['../class_s_c16_i_s740_s_p_i.html#a44b58ef1f07200e5833870f6756f6806',1,'SC16IS740SPI']]],
  ['stream',['Stream',['../class_stream.html',1,'']]]
];
