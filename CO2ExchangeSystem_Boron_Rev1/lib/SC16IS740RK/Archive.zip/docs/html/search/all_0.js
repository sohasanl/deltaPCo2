var searchData=
[
  ['available',['available',['../class_s_c16_i_s740_base.html#add1238897d62b180be873d70e905ea62',1,'SC16IS740Base::available()'],['../class_stream.html#a9c98a763395005c08ce95afb2f06c7b1',1,'Stream::available()']]],
  ['availableforwrite',['availableForWrite',['../class_s_c16_i_s740_base.html#acfcfdad402c86aa09b31c65e4cafeaa7',1,'SC16IS740Base']]]
];
