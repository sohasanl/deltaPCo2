var searchData=
[
  ['read',['read',['../class_s_c16_i_s740_base.html#a317591b7116239e3a8bff72cf2af62f6',1,'SC16IS740Base::read()'],['../class_s_c16_i_s740_base.html#a30405667b31b05ba7bdd0cd4cbdc6e79',1,'SC16IS740Base::read(uint8_t *buffer, size_t size)'],['../class_stream.html#aea5dee9fcb038148515b7c9212d38dc0',1,'Stream::read()']]],
  ['readbytes',['readBytes',['../class_stream.html#a45fd1336a323ea83b16e8507055f44ea',1,'Stream']]],
  ['readbytesuntil',['readBytesUntil',['../class_stream.html#af84672a4fb2620466958d3118d4fea00',1,'Stream']]],
  ['readinternal',['readInternal',['../class_s_c16_i_s740_base.html#a8a68a70c3d85c8c2e813fb0d2ac82160',1,'SC16IS740Base::readInternal()'],['../class_s_c16_i_s740.html#a798b6c4aa9634666e7e42955150eed1d',1,'SC16IS740::readInternal()'],['../class_s_c16_i_s740_s_p_i.html#a9f261741a927bc8a82ca1645696e0685',1,'SC16IS740SPI::readInternal()']]],
  ['readinternalmax',['readInternalMax',['../class_s_c16_i_s740_base.html#abbf5720dc9d1afa62a01fe89fdd814da',1,'SC16IS740Base::readInternalMax()'],['../class_s_c16_i_s740.html#ade0bee97e3adac4774eb1c849a99eaba',1,'SC16IS740::readInternalMax()'],['../class_s_c16_i_s740_s_p_i.html#ad671b1ac539adfb5798dc5d4548655af',1,'SC16IS740SPI::readInternalMax()']]],
  ['readregister',['readRegister',['../class_s_c16_i_s740_base.html#aad41df41746ab988b949b9c63215195d',1,'SC16IS740Base::readRegister()'],['../class_s_c16_i_s740.html#a04816f20154a877aa8b69106faedb0e6',1,'SC16IS740::readRegister()'],['../class_s_c16_i_s740_s_p_i.html#acf32f273e3b8a55e3ac978e2c60c245a',1,'SC16IS740SPI::readRegister()']]],
  ['readstring',['readString',['../class_stream.html#a1c60bdda2b65d78e5a1362d51b856c5a',1,'Stream']]],
  ['readstringuntil',['readStringUntil',['../class_stream.html#a6a409da87c552909260d8cc428c5ca70',1,'Stream']]]
];
