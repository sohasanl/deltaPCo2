var searchData=
[
  ['endtransaction',['endTransaction',['../class_s_c16_i_s740_s_p_i.html#a4605d3d7584bf74c173a7b282d92e5e5',1,'SC16IS740SPI']]]
];
