#pragma once


#include "Errors.h"
#include "SdFat.h"
#include "ActiveSerial.h"
#include "TinyGPS++.h"
#include "Particle.h"
#include "Cozir.h"
#include "Timing.h"
#include "SC16IS740RK.h"
#include "RTClib.h"
#include "TB6612.h"

//#include "SparkFun_Ublox_Arduino_Library.h"
//#include "Adafruit_GPS.h"
//#include "Particle-GPS.h"

#include <vector>
#include <algorithm>
#include <Wire.h>


 
namespace deltaPCo2{


struct SensorsData{
	float humidity;
	float temperature;
	int   co2;
	double  latitude;
	double  longitude;
};

#define SD_CS_PIN SS
#define PUMP A0
#define ON HIGH
#define OFF LOW

#define AIN1 D4
#define BIN1 D6
#define AIN2 D3
#define BIN2 D7
#define PWMA D2
#define PWMB D8
#define STBY D5

class PublishState;

class Peripherals {

public:
    Peripherals(USARTSerial& aUsartSerial, USBSerial& aUsbSerial);
    ~Peripherals();
    friend ostream& operator<<(ostream& os, const String aString);

    /////////////////////////////////////////////////
	// Methods
	///////////////////////////////////////////////// 

	SensorsData getSensorsData(T& aTimeTable);
	void writeSensorData();
	void getCo2(T& aTimeTable);
	void getHumidityAndTemp();
	void getGPS();
	void pump(byte state);
	void smartDelay(unsigned long ms);

    /////////////////////////////////////////////////
	// 
	///////////////////////////////////////////////// 

    
    friend class PublishState;
    friend class AppProcessor;

 protected:
    USARTSerial& serial;
    COZIR* czr;
    SdFat sd;
	RTC_PCF8523 rtc;
    ofstream sdout;
	SensorsData aData;
    ActiveSerial  anActiveSerial;
	SC16IS740 extSerial;
	std::vector<int>* co2List;
	Solenoid* valve1;
	Solenoid* valve2;
	TinyGPSPlus gps;
	//SFE_UBLOX_GPS myGPS;
    };
}