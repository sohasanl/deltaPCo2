
#ifndef TB6612_h
#define TB6612_h

#include <Arduino.h>

//used in some functions so you don't have to send a speed
#define DEFAULTSPEED 255  


class Solenoid
{
  public:
    // Constructor. Mainly sets up pins.
    Solenoid(int In1pin, int In2pin, int PWMpin, int STBYpin);

	//set the chip to standby mode.  The drive function takes it out of standby
	void standby();
    
    //functions that spin the motor CC and CCW
    void CA(int speed = DEFAULTSPEED);
    void CB(int speed = DEFAULTSPEED);
	
  private:
    //variables for the 2 inputs, PWM input, Offset value, and the Standby pin
	int In1, In2, PWM,Standby;
};

#endif
