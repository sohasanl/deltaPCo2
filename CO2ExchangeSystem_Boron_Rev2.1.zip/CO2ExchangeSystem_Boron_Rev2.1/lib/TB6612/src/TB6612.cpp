
#include "TB6612.h"
#include <Arduino.h>

Solenoid::Solenoid(int In1pin, int In2pin, int PWMpin, int STBYpin)
{
  In1 = In1pin;
  In2 = In2pin;
  PWM = PWMpin;
  Standby = STBYpin;
  pinMode(In1, OUTPUT);
  pinMode(In2, OUTPUT);
  pinMode(PWM, OUTPUT);
  pinMode(Standby, OUTPUT);
}

void Solenoid::CA(int speed)
{
   digitalWrite(Standby, HIGH);
   digitalWrite(In1, HIGH);
   digitalWrite(In2, LOW);
   analogWrite(PWM, speed);

}
void Solenoid::CB(int speed)
{
   digitalWrite(Standby, HIGH);
   digitalWrite(In1, LOW);
   digitalWrite(In2, HIGH);
   analogWrite(PWM, speed);
}

void Solenoid::standby()
{
   digitalWrite(Standby, LOW);
}



