#include "StateMachine.h"
#include "SleepState.h"
#include "PublishState.h"

namespace deltaPCo2{

StateMachine::StateMachine(USARTSerial& aUsartSerial, USBSerial& aUsbSerial)
    : Peripherals(aUsartSerial, aUsbSerial){
	m_CurrentState = new SleepState(); // Setting up current state...

	//===EEPROM Initialization===============================================
    //EEPROM.clear();
	TimeTable.get();
	if(TimeTable.init!='I'){
		TimeTable.init ='I';
		TimeTable.set(0.2, 12, 1.0, 2.0, 0.5, 0.5);
		TimeTable.put();
	}
	//========================================================================
}

StateMachine::~StateMachine() {
	if(m_CurrentState) {delete m_CurrentState;}
}


////////////////////////////////////////////////////////////
// State Machine Methods
////////////////////////////////////////////////////////////

bool StateMachine::publish() {
	if (m_CurrentState)
		return m_CurrentState->publish(this);
	return false;
}
bool StateMachine::sleep() {
	if (m_CurrentState) {return m_CurrentState->sleep(this);}
	return false;
}
bool StateMachine::readSensors() {
	if (m_CurrentState) {return m_CurrentState->readSensors(this);}
	return false;
}
bool StateMachine::log() {
	if (m_CurrentState) {return m_CurrentState->log(this);}
	return false;
}
bool StateMachine::wakeup() {
	if (m_CurrentState) {return m_CurrentState->wakeup(this);}
	return false;
}
void StateMachine::setCurrentState(State* currentState) {
	if (m_CurrentState) {
		delete m_CurrentState;
		m_CurrentState = NULL;
	}
	m_CurrentState = currentState;
}
}























