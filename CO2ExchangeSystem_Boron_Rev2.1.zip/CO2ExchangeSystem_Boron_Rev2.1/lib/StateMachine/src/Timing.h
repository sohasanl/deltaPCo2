#pragma once
#include "Particle.h"

namespace deltaPCo2{

#define TIMETABLE_ADDR 0
#define INIT_ADDR 0
#define LOGGING_FREQUENCY_ADDR 2
#define SAMPLING_RATE_ADDR     6
#define SAMPLING_DURATION_ADDR 10
#define SAMPLING_PERIOD_ADDR   14
#define SAMPLING_DURATION_AIR_ADDR 18
#define SAMPLING_DURATION_OCEAN_ADDR 22

struct T{
    char         init;
    float        loggingFrequency; //mins
    int          samplingRate; //Hertz
    float        samplingDuration; //mins
    float        samplingPeriod; //mins
    float        samplingDurationAir; //mins
    float        samplingDurationOcean; //mins

    T(){}

    T(float lf, int sr, float sd, float sp, float sda, float sdo)
    : loggingFrequency(lf), samplingRate(sr), samplingDuration(sd),
      samplingPeriod(sp), samplingDurationAir(sda), samplingDurationOcean(sdo){}

    void set(float lf, int sr, float sd, float sp, float sda, float sdo){
        loggingFrequency=lf;
        samplingRate=sr;
        samplingDuration=sd;
        samplingPeriod=sp;
        samplingDurationAir=sda;
        samplingDurationOcean=sdo;
    }
    
    void setLoggingFrequency(float lf){
        loggingFrequency=lf;
        EEPROM.put(LOGGING_FREQUENCY_ADDR,loggingFrequency);
    }
    void setSamplingRate(int sr){
        samplingRate=sr;
        EEPROM.put(SAMPLING_RATE_ADDR,samplingRate);
    }
    void setSamplingDuration(float sd){
        samplingDuration=sd;
        EEPROM.put(SAMPLING_DURATION_ADDR,samplingDuration);
    }
    void setSamplingPeriod(float sp){
        samplingPeriod=sp;
        EEPROM.put(SAMPLING_PERIOD_ADDR,samplingPeriod); 
    }
    void setSamplingDurationAir(float sda){
        samplingDurationAir=sda;
        EEPROM.put(SAMPLING_DURATION_AIR_ADDR,samplingDurationAir);
    }
        void setSamplingDurationOcean(float sdo){
        samplingDurationOcean=sdo;
        EEPROM.put(SAMPLING_DURATION_OCEAN_ADDR,samplingDurationOcean);
    }

    // float getLoggingFrequency(){
    //     EEPROM.get(LOGGING_FREQUENCY_ADDR,loggingFrequency);
    //     return loggingFrequency;
    // }
    // float getSamplingRate(){
    //     EEPROM.get(SAMPLING_RATE_ADDR,samplingRate);
    //     return samplingRate;
    // }
    // float getSamplingDuration(){
    //     EEPROM.get(SAMPLING_DURATION_ADDR,samplingDuration);
    //     return samplingDuration;
    // }
    // float getSamplingPeriod(){
    //     EEPROM.get(SAMPLING_PERIOD_ADDR,samplingPeriod);
    //     return  samplingPeriod;
    // }

    void put(){
		EEPROM.put(INIT_ADDR, init);
		EEPROM.put(LOGGING_FREQUENCY_ADDR, loggingFrequency);
    	EEPROM.put(SAMPLING_RATE_ADDR, samplingRate);
		EEPROM.put(SAMPLING_DURATION_ADDR, samplingDuration);
    	EEPROM.put(SAMPLING_PERIOD_ADDR, samplingPeriod);
        EEPROM.put(SAMPLING_DURATION_AIR_ADDR,samplingDurationAir);
        EEPROM.put(SAMPLING_DURATION_OCEAN_ADDR,samplingDurationOcean);  
    }
    void get(){
        EEPROM.get(INIT_ADDR, init); 
        EEPROM.get(LOGGING_FREQUENCY_ADDR, loggingFrequency);
        EEPROM.get(SAMPLING_RATE_ADDR, samplingRate); 
        EEPROM.get(SAMPLING_DURATION_ADDR, samplingDuration);
        EEPROM.get(SAMPLING_PERIOD_ADDR, samplingPeriod);
        EEPROM.get(SAMPLING_DURATION_AIR_ADDR,samplingDurationAir);
        EEPROM.get(SAMPLING_DURATION_OCEAN_ADDR,samplingDurationOcean);   
    }

    void dump(){
        Serial.print(" init: "); Serial.print(init);
        Serial.print(", lf: "); Serial.print(loggingFrequency);
        Serial.print(", sr: "); Serial.print(samplingRate);
        Serial.print(", sd: "); Serial.print(samplingDuration);
        Serial.print(", sp: "); Serial.print(samplingPeriod);
        Serial.print(", sda: "); Serial.print(samplingDurationAir);
        Serial.print(", sdo: "); Serial.println(samplingDurationOcean);
    }


};

extern T TimeTable;

}